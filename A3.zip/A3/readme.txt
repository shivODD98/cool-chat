Shiv Odedra / 30031173
https://github.com/shivODD98/cool-chat
Need to run the cmd 'node server.js' in cool-chat-server folder. Clone repo from github first